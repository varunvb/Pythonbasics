from distutils.core import setup

#setup(
#    name = 'yate',
#    version= '1.0',
#    py_modules= ['yate'],
#    author= 'varunvb',
#    author_email= 'varunvb3@gmail.com',
#    url= 'https://tesseract809.wordpress.com/',
#    description= 'A module to for view part of webApp'
#)

setup(
    name= 'athletemodel',
    version= '1.0',
    py_modules = ['athletemodel'],
    author= 'varunvb',
    author_email= 'varunvb3@gmail.com',
    url= 'https://tesseract809.wordpress.com/',
    description= 'A module for model part of webapp'
)
