from distutils.core import setup

setup(
    name  = 'sanitizedata',
    version = '1.0',
    py_modules = ['sanitizedata'],
    author     = 'varunvb',
    author_email = 'varunvb3@gmail.com',
    url          = 'https://tesseract809.wordpress.com/',
    description = 'A simple module to unify data splitters',
)